# Vue2 核心源码解析

## Flow 相关内容

类比 typescript 就可以了
然后可以稍微了解一下为什么当时会选择使用 flow 而不是 typescript，为什么 Vue3 完全拥抱 Typescript

## 如何阅读大型的开源项目源码

### 思路

- 了解核心流程 API，首先肯定要把库的 API 用熟（顺藤摸瓜）
- 整体执行流程
  - webpack/vite/gulp/【yeoman/grunt/rollup/esbuild/swc/turbopack/rspack 这俩不用看】：从启动到打包完输出
  - Vue2：Vue2 应用从编译到初始化到挂载到触发更新到卸载的整个流程
- 看 package,json，看依赖了哪些东西，有哪些命令

src
├── compiler # 编译相关
├── core # 核心代码
├── platforms # 不同平台的支持
├── server # 服务端渲染
├── sfc # .vue 文件解析
├── shared # 共享代码

lodash、underscore、ramda、rambda（有名的工具库，但是他没有太多学习参考意义）

new Vue({
id: '#ffff',
data: {

}
})

### 根据执行过程分析源码

1. 首先我们编写的是 xxx.vue 文件
2. sfc 用来将 .vue 文件转换为 js 文件
3. packages/compiler-sfc
4. compileTemplate、compileStyle、compileScript
5. compiler 用于编译处理
6. 启动项目，初始化应用，new Vue()
7. initGlobalAPI
   initUse(Vue)
   // Vue 插件化机制的初始化逻辑
   Vue.use(ElementUI)
   Vue.use(VueRouter)
   initMixin(Vue)
   initExtend(Vue)
   initAssetRegisters(Vue)
8. 处理一些初始化的逻辑，包含生命周期、Mixin 等内容
9. 创建对应 vdom，挂载（core/instance/render.ts）
10. 一旦发生更新（data 数据变更，通过监听触发）
    https://github.com/vuejs/vue/blob/1.1/src/observer/array.js
    patch 逻辑
    > 面试常问：Vue 中 :key 的作用
      Vue 响应式系统中，大量源码在做性能优化的事情，其中就包含 :key，在 diff 过程中，我们始终尝试着花费最小的代价，最大程度去进行节点复用，而 key 就作为我们判断节点是否可以复用的一大标准。

    [0, 1, 2, 3]：key=0,1,2,3
    [3, 2, 1, 0]：key=0,1,2,3

    div span
```js
function sameVnode(a, b) {
  return (
    a.key === b.key &&
    a.asyncFactory === b.asyncFactory &&
    ((a.tag === b.tag &&
      a.isComment === b.isComment &&
      isDef(a.data) === isDef(b.data) &&
      sameInputType(a, b)) ||
      (isTrue(a.isAsyncPlaceholder) && isUndef(b.asyncFactory.error)))
  );
}
```

8. 收集依赖
9. 处理更新，diff

### 双端 diff

diff 的目的是尽可能减少 dom 变更（reflow）（repaint），找到可以复用的节点（捡垃圾的）


<template>
  <div>
    <div>1</div>
    <div>2</div> <!-- 当鼠标点击时更新 -->
  </div>

  <div>
    <div>1</div>
    <div>3</div>
  </div>

  old： [1, 2]   new：[1, 3]   textContent
  diff

</template>

<!-- Vapor Mode -->
<!-- SFC  single file component -->
<template>
  <!-- html div -->
  <div></div>
  <!-- 小程序 -->
  <view></view>
  <!-- 跨平台一直在做一件事儿，就是想办法抹平不同平台间的差异 -->
</template>
<style></style>
<script>
  export default {
    data: {
      count: 0  // 点击鼠标变成 1
    }
  }
</script>
