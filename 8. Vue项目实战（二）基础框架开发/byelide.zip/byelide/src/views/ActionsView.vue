<script setup lang="ts">
import FlowEditor from '@/components/FlowEditor/FlowEditor.vue'
</script>

<template>
  <FlowEditor />
</template>
