<script setup lang="ts"></script>

<template>
  <h1 class="hero-title">hero title block</h1>
</template>

<style scoped>
.hero-title {
  font-size: 2rem;
  font-weight: 700;
  margin: 0;
}

.hero-title:hover {
  flex: 1;
}
</style>
