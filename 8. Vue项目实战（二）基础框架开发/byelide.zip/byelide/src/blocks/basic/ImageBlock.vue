<script setup lang="ts"></script>

<template>
  <div class="image">
    <img
      src="https://images.pexels.com/photos/2577274/pexels-photo-2577274.jpeg?auto=compress&cs=tinysrgb&w=1600"
    />
  </div>
</template>

<style scoped>
.image {
  width: 100%;
  border-radius: 8px;
  overflow: hidden;
}

img {
  width: 100%;
}
</style>
