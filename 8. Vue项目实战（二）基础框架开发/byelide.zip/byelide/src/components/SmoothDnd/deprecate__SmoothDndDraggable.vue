<script setup lang="ts"></script>

<template>
  <slot name="default"></slot>
</template>

<!-- <style scoped></style> -->
