export type PreviewType = 'mobile' | 'laptop'
