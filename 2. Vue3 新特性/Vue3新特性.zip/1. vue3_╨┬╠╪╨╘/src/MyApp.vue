<template>
	<img alt="Vue logo" src="./assets/logo.png" />
	<!-- 4. <async-comp /> -->
	<HelloWorld />
</template>

<script>
import HelloWorld from './components/HelloWorld.vue';

export default {
	name: 'MyApp',
	components: {
		HelloWorld,
	},
};
</script>
