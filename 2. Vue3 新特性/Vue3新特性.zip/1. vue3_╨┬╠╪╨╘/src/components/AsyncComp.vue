<template>
	<h1>async-comp</h1>
</template>

<script></script>
