// this is appended to the end of ../dist/vue.d.ts during build.
// imports the global JSX namespace registration for compat.
// TODO: remove in 3.4
import '../jsx'
