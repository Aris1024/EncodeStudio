// TODO remove in 3.4
import './macros-global'
