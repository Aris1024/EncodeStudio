# Vue3 核心源码解析

补充知识：
关于编译器的规范化和统一口径：https://www.antlr.org/

看源码的步骤：

1. 看 package.json
2. monorepo 项目的 packages/包
3. 分析流程
4. xxx.vue 文件先要经过编译 **compiler-sfc**
5. 应用初始化 **runtime-core**
6. 组件挂载 **runtime-core**
7. 数据的响应式处理 **reactive**
8. 触发数据更新 **runtime-core**
9. 将数据更新同步到视图 **runtime-dom**
10. 卸载

> monorepo，你现在公司有好几个项目，他们的依赖是不同的内部包，ui、utils、hooks、website、admin。用单个 git 仓库来存储多个项目
> monorepo：https://github.com/encode-studio-fe/encode-hooks

## vue3 源码的完整周期（几大阶段）

1. sfc 编译（Vue3 的编译时全新的基于状态机（https://leetcode.cn/problems/nGK0Fy/description/）的实现方式 https://www.google.com.hk/search?q=%E7%8A%B6%E6%80%81%E6%9C%BA%E5%AE%9E%E7%8E%B0%E7%BC%96%E8%AF%91&oq=%E7%8A%B6%E6%80%81%E6%9C%BA%E5%AE%9E%E7%8E%B0%E7%BC%96%E8%AF%91&gs_lcrp=EgZjaHJvbWUyBggAEEUYOdIBCDQ1OTVqMGoxqAIAsAIA&sourceid=chrome&ie=UTF-8，Vue2 中使用的是模式匹配【正则匹配】）
2. 响应系统的初始化
3. 依赖收集
  `/packages/reactivity/src/collectionHandlers.ts`
  一旦响应式中某个属性被访问，它就会调用一下 track
  ```ts
    type Dep = Set<ReactiveEffect> & TrackedMarkers
    type KeyToDepMap = Map<any, Dep>
    const targetMap = new WeakMap<any, KeyToDepMap>()
  ```
  1. 具体流程，proxy 代理，在 get 方法中，决定追踪策略，然后通过定义的 track 进行属性追踪，在依赖 map 中追加对应的依赖追踪
4. 响应式属性更新
5. 重新渲染组件
6. 更新完毕

## diff 算法

### 简单 diff（只是我拿来教学用）暴力解法

### 双端 diff

### 快速 diff


