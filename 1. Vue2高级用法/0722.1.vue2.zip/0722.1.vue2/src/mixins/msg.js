export const mixin1 = {
  data() {
    return {
      msg1: "mixin1",
    };
  },
  created() {
    console.log("mixin1 created");
  },
  methods: {
    test() {
      console.log("mixin1 test");
    },
    change() {
      this.msg1 = "mixin1 changed";
    },
  },
};
