<script setup lang="ts">
import { toRaw } from 'vue'
import { Drag, Delete } from '@icon-park/vue-next'
import { useEnvStore } from '@/stores/debug'
import { useAppEditorStore } from '@/stores/appEditor'
import { smoothDnD, type DropResult, dropHandlers } from 'smooth-dnd'
import { arrayMove } from '@/utils/array'

import { SmoothDndContainer } from '@/components/SmoothDnd/SmoothDndContainer'
import { SmoothDndDraggable } from '@/components/SmoothDnd/SmoothDndDraggable'
import { storeToRefs } from 'pinia'

smoothDnD.dropHandler = dropHandlers.reactDropHandler().handler

// const props = defineProps<{
//   type: BlockType
// }>()

const envStore = useEnvStore()
const appEditorStore = useAppEditorStore()

const { currentBlockId, blocks } = storeToRefs(appEditorStore)
const { selectBlock, updateBlocks } = appEditorStore

const applyDrag = <T extends any[]>(arr: T, dragResult: DropResult) => {
  const { removedIndex, addedIndex, payload } = dragResult

  const result = [...arr]

  // 没做操作
  if (addedIndex === null) return result

  // 添加
  if (addedIndex !== null && removedIndex === null) {
    result.splice(addedIndex, 0, {
      id: `${Math.random()}`,
      ...payload
    })
  }

  // 移动
  if (addedIndex !== null && removedIndex !== null) {
    return arrayMove(result, removedIndex, addedIndex)
  }

  return result
}
</script>

<template>
  <smooth-dnd-container
    drag-handle-selector=".handle"
    group-name="blocks"
    orientation="vertical"
    tag="div"
    @drop="updateBlocks(applyDrag(toRaw(blocks), $event))"
  >
    <smooth-dnd-draggable v-for="(block, i) in blocks" :key="block.id">
      <div class="block-wrapper" @click.stop="selectBlock(block.id)">
        <!-- @vue-ignore -->
        <component :is="$blocksMap[block.type].material" class="block" />
        <div
          :class="[
            'block-wrapper-indicator',
            { shown: envStore.debug, selected: currentBlockId === block.id }
          ]"
        >
          <div class="block-toolbar" v-if="currentBlockId === block.id">
            <div class="block-toolbar-item handle">
              <drag />
            </div>
            <div class="block-toolbar-item" @click="blocks.splice(i, 1)">
              <delete />
            </div>
          </div>
        </div>
      </div>
    </smooth-dnd-draggable>
  </smooth-dnd-container>
  <!-- <div ref="containerRef">
    <div
      class="block-wrapper"
      v-for="(d, i) in b"
      :key="d.id"
      @click.stop="appEditorStore.selectBlock(d.id)"
    >
      <component :is="d.material" class="block" />
      <div
        :class="[
          'block-wrapper-indicator',
          { shown: envStore.debug, selected: appEditorStore.currentBlockId === d.id }
        ]"
      >
        <div class="block-toolbar" v-if="appEditorStore.currentBlockId === d.id">
          <div class="block-toolbar-item handle">
            <drag />
          </div>
          <div class="block-toolbar-item" @click="b.splice(i, 1)">
            <delete />
          </div>
        </div>
      </div>
    </div>
  </div> -->
</template>

<style scoped>
.block-wrapper {
  position: relative;
  display: flex;
  width: 100%;
  margin-top: 16px;
  padding: 6px 4px;
  border-radius: 8px;
  background-color: var(--color-white);
  transition: box-shadow 0.2s ease-in-out;
}

.block {
  position: relative;
  z-index: 1;
}

.block-wrapper-indicator {
  content: '';
  position: absolute;
  width: 100%;
  height: 100%;
  left: 0;
  top: 0;
  border-radius: 8px;
  pointer-events: none;
  user-select: none;
}

.block-wrapper-indicator.shown {
  border: 1px dashed var(--color-gray-300);
}

.block-wrapper-indicator.selected {
  border: 1px solid var(--color-primary);
}

.block-toolbar {
  display: flex;
  align-items: center;
  position: absolute;
  left: 0;
  top: -36px;
  z-index: 1;
  padding: 4px 8px;
  gap: 4px;
  background-color: var(--color-black);
  border-radius: 6px;
  pointer-events: visible;
}

.block-toolbar-item {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 22px;
  height: 22px;
  border-radius: 4px;
  color: var(--color-white);
  cursor: pointer;
}

.block-toolbar-item:nth-of-type(1) {
  cursor: grab;
}

.block-toolbar-item:hover {
  background-color: var(--color-gray-800);
  transition: all 0.2s ease-in-out;
}

.block-wrapper.debug:hover .block-wrapper-senior {
  border-style: solid;
  transition: box-shadow 0.2s ease-in-out;
}
</style>

<style lang="css">
.smooth-dnd-draggable-wrapper {
  overflow: visible !important;
}
</style>
