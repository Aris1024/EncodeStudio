<script setup lang="ts"></script>

<template>
  <div class="left-panel-wrapper">chart block</div>
</template>

<!-- <style scoped></style> -->
