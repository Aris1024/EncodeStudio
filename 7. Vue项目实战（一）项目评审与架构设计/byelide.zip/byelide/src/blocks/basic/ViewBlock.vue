<script setup lang="ts"></script>

<template>
  <div class="left-panel-wrapper">view block</div>
</template>

<!-- <style scoped></style> -->
